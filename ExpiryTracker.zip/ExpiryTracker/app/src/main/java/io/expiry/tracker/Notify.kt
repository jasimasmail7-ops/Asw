package io.expiry.tracker
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.*
import java.time.LocalDate
import java.util.concurrent.TimeUnit

class CheckWorker(c:Context,p:WorkerParameters):CoroutineWorker(c,p){
 override suspend fun doWork():Result{
  val ctx=applicationContext; val d=ctx.getSharedPreferences("s",0).getInt("days",3); val t=LocalDate.now().toEpochDay()
  val due=Db.get(ctx).dao().list().filter{it.expiry-t<=d}
  if(due.isNotEmpty()&&NotificationManagerCompat.from(ctx).areNotificationsEnabled()){
   val nm=ctx.getSystemService(NotificationManager::class.java)
   nm.createNotificationChannel(NotificationChannel("exp","Expiry",NotificationManager.IMPORTANCE_DEFAULT))
   val n=NotificationCompat.Builder(ctx,"exp").setSmallIcon(android.R.drawable.ic_dialog_info)
    .setContentTitle(ctx.getString(R.string.app_name)).setContentText(due.take(4).joinToString{it.name}+if(due.size>4)"…" else "").build()
   nm.notify(1,n)}
  return Result.success()}}
fun schedule(c:Context){WorkManager.getInstance(c).enqueueUniquePeriodicWork("chk",ExistingPeriodicWorkPolicy.KEEP,
 PeriodicWorkRequestBuilder<CheckWorker>(1,TimeUnit.DAYS).build())}
