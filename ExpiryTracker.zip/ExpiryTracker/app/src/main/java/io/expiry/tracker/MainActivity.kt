package io.expiry.tracker
import android.Manifest
import android.app.DatePickerDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.*
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import kotlinx.coroutines.launch
import java.io.File
import java.time.LocalDate

val CATS=listOf("Food","Drinks","Medicine","Supplements","Cosmetics","Household")
val LOCS=listOf("Fridge","Freezer","Pantry","Medicine cabinet","Bathroom","Other")
val RED=Color(0xFFD32F2F);val AMB=Color(0xFFF9A825);val GRN=Color(0xFF2E7D32)
fun days(i:Item)=(i.expiry-LocalDate.now().toEpochDay()).toInt()
fun tone(d:Int,soon:Int)=if(d<0)RED else if(d<=soon)AMB else GRN
fun blank(code:String?=null,p:Product?=null)=Item(name=p?.name?:"",category="Food",location="Fridge",
 expiry=LocalDate.now().plusDays(7).toEpochDay(),photo=p?.image,barcode=code)

class MainActivity:ComponentActivity(){
 override fun onCreate(s:Bundle?){super.onCreate(s); schedule(this)
  if(Build.VERSION.SDK_INT>=33) registerForActivityResult(ActivityResultContracts.RequestPermission()){}.launch(Manifest.permission.POST_NOTIFICATIONS)
  setContent{
   val p=remember{getSharedPreferences("s",0)}; var theme by remember{mutableIntStateOf(p.getInt("theme",0))}
   val dark=when(theme){1->false;2->true;else->isSystemInDarkTheme()}
   MaterialTheme(if(dark)darkColorScheme() else lightColorScheme()){Surface(Modifier.fillMaxSize()){
    Root(p,theme){theme=it;p.edit().putInt("theme",it).apply()}}}}}}

@Composable fun Root(p:SharedPreferences,theme:Int,setTheme:(Int)->Unit){
 val ctx=LocalContext.current; val dao=remember{Db.get(ctx).dao()}; val scope=rememberCoroutineScope()
 val all by dao.all().collectAsState(emptyList())
 var edit by remember{mutableStateOf<Item?>(null)}; var settings by remember{mutableStateOf(false)}
 var scanned by remember{mutableStateOf<String?>(null)}; var soon by remember{mutableIntStateOf(p.getInt("days",3))}
 BackHandler(edit!=null||settings){edit=null;settings=false}
 val e=edit
 when{
  e!=null->Editor(e,{edit=null},{scope.launch{dao.del(e)};edit=null}){scope.launch{dao.save(it)};edit=null}
  settings->Settings(soon,theme,all,{soon=it;p.edit().putInt("days",it).apply()},setTheme){settings=false}
  else->Home(all,soon,{edit=it},{edit=blank()},{GmsBarcodeScanning.getClient(ctx).startScan().addOnSuccessListener{b->b.rawValue?.let{scanned=it}}},{settings=true})}
 scanned?.let{c->ScanDialog(c,dao,{scanned=null},{edit=blank(c,it);scanned=null})}}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun Home(all:List<Item>,soon:Int,open:(Item)->Unit,add:()->Unit,scan:()->Unit,settings:()->Unit){
 var loc by remember{mutableStateOf("All")}; val shown=all.filter{loc=="All"||it.location==loc}
 Scaffold(topBar={TopAppBar(title={Text(stringResource(R.string.app_name))},actions={IconButton(settings){Icon(Icons.Default.Settings,null)}})},
  floatingActionButton={Column(horizontalAlignment=Alignment.End,verticalArrangement=Arrangement.spacedBy(8.dp)){
   ExtendedFloatingActionButton(onClick=scan){Text(stringResource(R.string.scan))}
   FloatingActionButton(onClick=add){Icon(Icons.Default.Add,null)}}}){pad->
  LazyColumn(Modifier.padding(pad),contentPadding=PaddingValues(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
   item{Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
    Stat(stringResource(R.string.expired),all.count{days(it)<0},RED,Modifier.weight(1f))
    Stat(stringResource(R.string.soon),all.count{days(it) in 0..soon},AMB,Modifier.weight(1f))}}
   item{LazyRow(horizontalArrangement=Arrangement.spacedBy(8.dp)){items(listOf("All")+LOCS){FilterChip(loc==it,{loc=it},{Text(it)})}}}
   items(shown,key={it.id}){i->val d=days(i)
    Card(onClick={open(i)}){Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically){
     if(i.photo!=null)AsyncImage(i.photo,null,Modifier.size(48.dp).clip(MaterialTheme.shapes.small),contentScale=ContentScale.Crop)
     Column(Modifier.weight(1f).padding(start=12.dp)){Text(i.name,fontWeight=FontWeight.Bold);Text("${i.location} · ${i.category}",style=MaterialTheme.typography.bodySmall)}
     Text(if(d<0)stringResource(R.string.expired) else "${d}d",color=tone(d,soon),fontWeight=FontWeight.Bold)}}}}}}

@Composable fun Stat(label:String,n:Int,c:Color,m:Modifier)=Card(m){Column(Modifier.padding(12.dp)){Text("$n",color=c,style=MaterialTheme.typography.headlineMedium);Text(label)}}

@Composable fun Editor(init:Item,close:()->Unit,delete:()->Unit,save:(Item)->Unit){
 val ctx=LocalContext.current; var v by remember{mutableStateOf(init)}
 val pick=rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()){u->if(u!=null){
  val f=File(ctx.filesDir,"${System.nanoTime()}.jpg"); ctx.contentResolver.openInputStream(u)?.use{i->f.outputStream().use{o->i.copyTo(o)}}
  v=v.copy(photo=Uri.fromFile(f).toString())}}
 Column(Modifier.statusBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
  IconButton(close){Icon(Icons.AutoMirrored.Filled.ArrowBack,null)}
  OutlinedTextField(v.name,{v=v.copy(name=it)},Modifier.fillMaxWidth(),label={Text(stringResource(R.string.name))})
  LazyRow(horizontalArrangement=Arrangement.spacedBy(8.dp)){items(CATS){FilterChip(v.category==it,{v=v.copy(category=it)},{Text(it)})}}
  LazyRow(horizontalArrangement=Arrangement.spacedBy(8.dp)){items(LOCS){FilterChip(v.location==it,{v=v.copy(location=it)},{Text(it)})}}
  OutlinedButton({val d=LocalDate.ofEpochDay(v.expiry)
   DatePickerDialog(ctx,{_,y,m,dd->v=v.copy(expiry=LocalDate.of(y,m+1,dd).toEpochDay())},d.year,d.monthValue-1,d.dayOfMonth).show()},Modifier.fillMaxWidth()){
   Text("${stringResource(R.string.expiry)}: ${LocalDate.ofEpochDay(v.expiry)}")}
  OutlinedTextField(v.barcode?:"",{v=v.copy(barcode=it.ifBlank{null})},Modifier.fillMaxWidth(),label={Text(stringResource(R.string.barcode))})
  OutlinedTextField(v.notes,{v=v.copy(notes=it)},Modifier.fillMaxWidth(),label={Text(stringResource(R.string.notes))})
  v.photo?.let{AsyncImage(it,null,Modifier.height(160.dp).fillMaxWidth(),contentScale=ContentScale.Fit)}
  OutlinedButton({pick.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))}){Text(stringResource(R.string.photo))}
  if(v.id!=0L)OutlinedButton({ctx.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://www.google.com/search?q="+Uri.encode("recipes with ${v.name}"))))}){Text(stringResource(R.string.recipes))}
  Button({save(v)},Modifier.fillMaxWidth(),enabled=v.name.isNotBlank()){Text(stringResource(R.string.save))}
  if(v.id!=0L)TextButton(delete){Text(stringResource(R.string.delete),color=RED)}}}

@Composable fun ScanDialog(code:String,dao:ItemDao,close:()->Unit,add:(Product?)->Unit){
 var prod by remember{mutableStateOf<Product?>(null)}; var msg by remember{mutableStateOf<Int?>(R.string.checking)}; var inv by remember{mutableStateOf<Item?>(null)}
 LaunchedEffect(code){inv=dao.byBarcode(code)
  try{prod=lookup(code);msg=if(prod==null)R.string.not_found else null}catch(e:Exception){msg=R.string.offline}}
 AlertDialog(close,title={Text(code)},
  confirmButton={TextButton({add(prod)}){Text(stringResource(R.string.add))}},dismissButton={TextButton(close){Text("✕")}},
  text={Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(6.dp)){
   inv?.let{Text("${stringResource(R.string.in_inv)}: ${it.name} (${it.location})",color=AMB,fontWeight=FontWeight.Bold)}
   msg?.let{Text(stringResource(it))}
   prod?.let{p->Text(stringResource(R.string.found),color=GRN,fontWeight=FontWeight.Bold)
    p.image?.let{AsyncImage(it,null,Modifier.height(140.dp).fillMaxWidth(),contentScale=ContentScale.Fit)}
    Text(p.name,style=MaterialTheme.typography.titleMedium)
    listOf(p.brand,p.quantity,p.categories,p.ingredients).filter{it.isNotBlank()}.forEach{Text(it,style=MaterialTheme.typography.bodySmall)}}}})}

@Composable fun Settings(soon:Int,theme:Int,all:List<Item>,setSoon:(Int)->Unit,setTheme:(Int)->Unit,back:()->Unit){
 val ctx=LocalContext.current
 Column(Modifier.statusBarsPadding().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
  IconButton(back){Icon(Icons.AutoMirrored.Filled.ArrowBack,null)}
  Text("${stringResource(R.string.reminder)}: $soon")
  Slider(soon.toFloat(),{setSoon(it.toInt())},valueRange=1f..30f)
  Text(stringResource(R.string.theme))
  Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){listOf("System","Light","Dark").forEachIndexed{i,t->FilterChip(theme==i,{setTheme(i)},{Text(t)})}}
  Button({val csv="name,category,location,expiry,barcode,notes\n"+all.joinToString("\n"){"\"${it.name}\",${it.category},${it.location},${LocalDate.ofEpochDay(it.expiry)},${it.barcode?:""},\"${it.notes}\""}
   ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT,csv),null))}){Text(stringResource(R.string.export))}}}
