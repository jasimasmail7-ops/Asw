package io.expiry.tracker
import android.content.Context
import androidx.room.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URL

@Entity data class Item(@PrimaryKey(autoGenerate=true) val id:Long=0,val name:String,val category:String,val location:String,
 val expiry:Long,val photo:String?=null,val barcode:String?=null,val notes:String="")
@Dao interface ItemDao{
 @Query("SELECT * FROM Item ORDER BY expiry") fun all():Flow<List<Item>>
 @Query("SELECT * FROM Item") suspend fun list():List<Item>
 @Query("SELECT * FROM Item WHERE barcode=:b LIMIT 1") suspend fun byBarcode(b:String):Item?
 @Upsert suspend fun save(i:Item)
 @Delete suspend fun del(i:Item)}
@Database(entities=[Item::class],version=1,exportSchema=false) abstract class Db:RoomDatabase(){
 abstract fun dao():ItemDao
 companion object{@Volatile private var i:Db?=null
  fun get(c:Context)=i?:synchronized(this){Room.databaseBuilder(c.applicationContext,Db::class.java,"e.db").build().also{i=it}}}}

// NEW FEATURE: barcode lookup (Open Food Facts - free, no API key)
data class Product(val name:String,val brand:String,val quantity:String,val categories:String,val image:String?,val ingredients:String)
suspend fun lookup(code:String):Product?=withContext(Dispatchers.IO){
 val u="https://world.openfoodfacts.org/api/v2/product/$code.json?fields=product_name,brands,quantity,categories,image_url,ingredients_text"
 val j=JSONObject(URL(u).readText()) // throws on network error
 if(j.optInt("status")!=1) null else j.getJSONObject("product").let{
  Product(it.optString("product_name"),it.optString("brands"),it.optString("quantity"),it.optString("categories"),
   it.optString("image_url").ifBlank{null},it.optString("ingredients_text"))}}
