Open this folder in Android Studio (Koala or newer), let Gradle sync, press Run. Needs Google Play Services on the device (for the ML Kit barcode scanner).
